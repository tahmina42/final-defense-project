<?php
include("functions.php");
{
	
	$logout=new functions();
	$logout->logout();
}
?>


